CHARAKTERYSTYKA SŁUCHOTEK (UCHOWCÓW)

Liczba obserwacji: 4177

Atrybuty (kolumny):
1. płeć (ang. sex) - cecha nominalna:
   M - samiec (ang. male)
   F - samica (ang. female)
   I - jeszcze niewykształcona ze względu na zbyt młody wiek (ang. infant)
2. długość (ang. length) [mm] - cecha ciągła
3. średnica (ang. diameter) [mm] - cecha ciągła
4. wysokość (ang. height) [mm] - cecha ciągła
5. masa całkowita (ang. whole weight) [g] - cecha ciągła
6. masa po wyjęciu z muszli (ang. shucked weight) [g] - cecha ciągła
7. masa trzewi (ang. viscera weight) po wykrwawieniu [g] - cecha ciągła
8. masa muszli (ang. shell weight) po osuszeniu [g] - cecha ciągła
9. pierścienie (ang. rings) - cecha skokowa o wartościach całkowitych

Kolumny oddzielone są przecinkami.
